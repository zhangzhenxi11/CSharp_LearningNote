# WpfDiagram
WPF拖动控件

代码来自网络，版权归原作者所有

![](snapshot-1.png)

![](snapshot-2.png)
