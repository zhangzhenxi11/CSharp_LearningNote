﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aga.Diagrams.Controls
{
	public enum LinkThumbKind
	{
		Source, Target
	}
}
